public interface IGameManager
{
    public static ILobbySceneManager lobbySceneManager;

    public static IMainSceneManager mainSceneManager;

    public static ITitleSceneManager titleSceneManager;
}
