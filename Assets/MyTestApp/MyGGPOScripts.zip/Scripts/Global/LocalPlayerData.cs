using UnityEngine;

public static class LocalPlayerData
{
    public static Color hatCol;
    public static int charaId;
    public static Color umaCol;
}
