using System;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Cysharp.Threading.Tasks;
using Epic.OnlineServices;
using Epic.OnlineServices.P2P;
using PlayEveryWare.EpicOnlineServices;
using PlayEveryWare.EpicOnlineServices.Samples;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.tvOS;

/// <summary>
/// 2�l�Œ� + Ready�����F
/// Lobby��members/READY���Ď����A����Ready������P2P handshake�iAccept + Ping/Pong�j������������B
/// ���������� OnConnected(remotePuid) �𔭉΁B���f������������ Stop() �Ŋm���Ɍ�n������B
/// </summary>
public sealed class P2PReadyCoordinator : IDisposable
{
    public enum State
    {
        Stopped,
        WaitingLobby,
        WaitingReady,
        Handshaking,
        Connected,
    }

    public event Action<State> OnStateChanged;
    public event Action<ProductUserId> OnConnected;
    public event Action<string> OnAborted;
    public event Action<string> OnError;

    // ====== �ݒ� ======
    public string SOCKET_NAME = "GAME"; // 2�l�Œ�Ȃ炱��1��OK
    public int PollIntervalMs = 200;

    public int HandshakeTimeoutMs = 6000; // Ping/Pong����������܂ł̗P�\
    public int PingIntervalMs = 500;
    public int PingMaxTries = 10;

    // ====== �O���ˑ� ======
    private EOSLobbyManager _lobbyManager;            // ���Ȃ��� LobbyService
    private Func<P2PInterface> _getP2P;            // P2PInterface�̎擾���@�𒍓��i�v���W�F�N�g�����z���j

    // ====== ������� ======
    private CancellationTokenSource _cts;
    private State _state = State.Stopped;

    private ProductUserId _remotePuid;             // handshaking�J�n���Ɋm�肵�ČŒ�
    private SocketId _socketId;

    private ulong _notifyPeerRequestId = 0;
    private bool _notifyRegistered = false;

    // ��M�o�b�t�@�i�K���ɑ傫�߁j
    private readonly byte[] _recvBuffer = new byte[4096];

    public State CurrentState => _state;

    public P2PReadyCoordinator(EOSLobbyManager lm)
    {
        _getP2P = () => EOSManager.Instance.GetEOSPlatformInterface().GetP2PInterface();
        _lobbyManager = lm;
    }

    IEosService IEosService;

    public void Init(IEosService _eosService)
    {
        IEosService = _eosService;

        Stop(); // ���d�N���h�~
        _socketId = new SocketId { SocketName = SOCKET_NAME };
        _cts = new CancellationTokenSource();
        SetState(State.WaitingLobby);

        RunLoop(_cts.Token).Forget();
    }

    public void Stop()
    {
        if (_cts != null)
        {
            _cts.Cancel();
            _cts.Dispose();
            _cts = null;
        }

        // P2P��n���inotify����/connection close�j
        CleanupP2P();

        _remotePuid = null;
        SetState(State.Stopped);
    }

    public void Dispose()
    {
        Stop();
    }

    // ====== ���C���Ď����[�v ======
    private async UniTaskVoid RunLoop(CancellationToken ct)
    {
        try
        {
            // notify�́u�󂯓��ꏀ���v�Ƃ��Đ�ɏ풓������i��肱�ڂ��h�~�j
            EnsureNotifyRegistered();

            while (!ct.IsCancellationRequested)
            {
                Lobby currentLobby = _lobbyManager.GetCurrentLobby();

                if (currentLobby == null)
                {
                    SetState(State.WaitingLobby);
                    await UniTask.Delay(PollIntervalMs, cancellationToken: ct);
                    UnityEngine.Debug.Log("���r�[�����擾��");
                    continue;
                }

                var members = currentLobby.Members;

                if (members == null || members.Count != 2)
                {
                    // 2�l�Œ�F�������Ȃ��Ȃ�Handshake/Connected�͈ێ����Ȃ�
                    if (_state == State.Handshaking || _state == State.Connected)
                    {
                        Abort("members.Count != 2");
                    }
                    else
                    {
                        SetState(State.WaitingReady);
                    }

                    UnityEngine.Debug.Log("�ΐ푊��҂��󂯒�");
                    await UniTask.Delay(PollIntervalMs, cancellationToken: ct);
                    continue;
                }

                // local/remote ����iremote�� handshaking �J�n���ɌŒ肷��j
                var localMember = members.FirstOrDefault(m => m.ProductId == IEosService.myPuid);
                var remoteMember = members.FirstOrDefault(m => m.ProductId != IEosService.myPuid);

                if (localMember == null || remoteMember == null)
                {
                    if (_state == State.Handshaking || _state == State.Connected)
                        Abort("localMember or remoteMember missing");
                    else
                        SetState(State.WaitingReady);

                    await UniTask.Delay(PollIntervalMs, cancellationToken: ct);
                    continue;
                }

                // READY ����iTryGetValue���s�� false �����j
                bool localReady = TryGetReady(localMember);
                bool remoteReady = TryGetReady(remoteMember);

                // ��M�����͏�ɉ񂷁iPING�ւ̉����Ȃǁj
                PumpReceive(remoteMember.ProductId);

                if (!localReady || !remoteReady)
                {
                    if (_state == State.Handshaking || _state == State.Connected)
                        Abort("ready became false");
                    else
                        SetState(State.WaitingReady);


                    UnityEngine.Debug.Log("�����o�[�̏��������҂�");

                    await UniTask.Delay(PollIntervalMs, cancellationToken: ct);
                    continue;
                }

                // Ready����
                if (_state == State.WaitingReady || _state == State.WaitingLobby)
                {
                    _remotePuid = remoteMember.ProductId; // �����Ŋm��
                    SetState(State.Handshaking);

                    bool ok = await DoHandshake(_remotePuid, ct);
                    if (ok)
                    {
                        SetState(State.Connected);
                        Debug.Log($"[P2P] Connected with {_remotePuid}");
                        OnConnected?.Invoke(_remotePuid);
                    }
                    else
                    {
                        Abort("handshake failed");
                    }
                }

                await UniTask.Delay(PollIntervalMs, cancellationToken: ct);
            }
        }
        catch (OperationCanceledException)
        {
            // Stop�ɂ��L�����Z���͐���
        }
        catch (Exception ex)
        {
            OnError?.Invoke(ex.ToString());
            Abort("exception");
        }
    }

    private bool TryGetReady(LobbyMember lobbyMember)
    {
        try
        {
            if (lobbyMember.MemberAttributes == null) return false;

            // MemberAttributes.TryGetValue ���g����O��
            if (!lobbyMember.MemberAttributes.TryGetValue(IEosService.MEMBER_KEY_READY, out var att)) return false;

            // AsString �� "1" �Ȃ� ready
            string s = att.AsString;
            return s == "1";
        }
        catch
        {
            return false;
        }
    }

    // ====== P2P handshake ======
    private async UniTask<bool> DoHandshake(ProductUserId remote, CancellationToken ct)
    {
        EnsureNotifyRegistered();

        // Accept�i�����œ����ɌĂ��OK�j
        if (!Accept(remote))
            return false;

        // Ping/Pong �a�ʊm�F
        int tries = 0;
        var start = Time.realtimeSinceStartup;

        while (!ct.IsCancellationRequested)
        {
            tries++;

            // PING���M
            SendText(remote, "PING:" + DateTimeOffset.UtcNow.ToUnixTimeMilliseconds());
            Debug.Log($"[P2P][PING->] to {remote}");

            // ��M�������񂵂āAPONG�҂�
            var pong = await WaitForPong(remote, PingIntervalMs, ct);
            if (pong)
                return true;

            // timeout / tries
            float elapsedMs = (Time.realtimeSinceStartup - start) * 1000f;
            if (elapsedMs >= HandshakeTimeoutMs) return false;
            if (tries >= PingMaxTries) return false;
        }

        return false;
    }

    private bool WaitedPongFlag = false;

    private async UniTask<bool> WaitForPong(ProductUserId remote, int waitMs, CancellationToken ct)
    {
        WaitedPongFlag = false;

        float start = Time.realtimeSinceStartup;
        while (!ct.IsCancellationRequested)
        {
            PumpReceive(remote);

            if (WaitedPongFlag)
                return true;

            float elapsedMs = (Time.realtimeSinceStartup - start) * 1000f;
            if (elapsedMs >= waitMs)
                return false;

            await UniTask.Yield(PlayerLoopTiming.Update, ct);
        }
        return false;
    }

    // ====== P2P receive / respond ======
    private void PumpReceive(ProductUserId remote)
    {
        var p2p = _getP2P?.Invoke();
        if (p2p == null) return;

        // ��M���\�Ȍ���J���i�t���[�����Ő�����x�j
        for (int i = 0; i < 8; i++)
        {
            var receiveOptions = new ReceivePacketOptions
            {
                LocalUserId = IEosService.myPuid,
                MaxDataSizeBytes = (uint)_recvBuffer.Length,
                RequestedChannel = null, // �`�����l�����w��
            };

            var socketId = _socketId;
            var outPeerId = default(ProductUserId);
            var outChannel = default(byte);
            uint outBytesWritten = 0;

            var result = p2p.ReceivePacket(ref receiveOptions, ref outPeerId, ref socketId, out outChannel, _recvBuffer, out outBytesWritten);
            if (result != Result.Success)
                break;

            if (outPeerId == null || outBytesWritten == 0)
                continue;

            // ����ȊO�͖����i2�l�Œ�j
            if (outPeerId != remote)
                continue;

            string msg = Encoding.UTF8.GetString(_recvBuffer, 0, (int)outBytesWritten);

            // �ŏ��v���g�R���FPING�ɂ�PONG�ŕԂ� / PONG��������t���O
            if (msg.StartsWith("PING"))
            {
                SendText(remote, "PONG");
            }
            else if (msg.StartsWith("PONG"))
            {
                Debug.Log($"[P2P][<-PONG] from {remote} (Handshake OK)");
                WaitedPongFlag = true;
            }
        }
    }

    private bool SendText(ProductUserId remote, string text)
    {
        var p2p = _getP2P?.Invoke();
        if (p2p == null) return false;

        byte[] data = Encoding.UTF8.GetBytes(text);

        var sendOptions = new SendPacketOptions
        {
            LocalUserId = IEosService.myPuid,
            RemoteUserId = remote,
            SocketId = _socketId,
            Channel = 0,
            Data = data,
            //DataLengthBytes = (uint)data.Length,
            AllowDelayedDelivery = true,
            //DeliveryReliability = PacketReliability.ReliableUnordered, // �a�ʊm�F�͂����OK
        };

        var r = p2p.SendPacket(ref sendOptions);
        return r == Result.Success;
    }

    private bool Accept(ProductUserId remote)
    {
        var p2p = _getP2P?.Invoke();
        if (p2p == null) return false;

        var opt = new AcceptConnectionOptions
        {
            LocalUserId = IEosService.myPuid,
            RemoteUserId = remote,
            SocketId = _socketId
        };

        var r = p2p.AcceptConnection(ref opt);
        return r == Result.Success || r == Result.AlreadyPending; // Already�n�͊��ŏo��̂ŋ��e
    }

    // ====== notify ======
    private void EnsureNotifyRegistered()
    {
        if (_notifyRegistered) return;

        var p2p = _getP2P?.Invoke();
        if (p2p == null) return;

        var opt = new AddNotifyPeerConnectionRequestOptions
        {
            LocalUserId = IEosService.myPuid,
            SocketId = _socketId
        };

        _notifyPeerRequestId = p2p.AddNotifyPeerConnectionRequest(ref opt, null, (ref OnIncomingConnectionRequestInfo data) =>
        {
            // �����Łu������Accept�v���Ă����Ƃ�茘���i����̐�s�v������肱�ڂ��Ȃ��j
            if (data.RemoteUserId != null)
            {
                Accept(data.RemoteUserId);
            }
        });

        _notifyRegistered = _notifyPeerRequestId != 0;
    }

    // ====== cleanup ======
    private void CleanupP2P()
    {
        var p2p = _getP2P?.Invoke();
        if (p2p != null)
        {
            if (_notifyRegistered && _notifyPeerRequestId != 0)
            {
                p2p.RemoveNotifyPeerConnectionRequest(_notifyPeerRequestId);
            }

            if (_remotePuid != null)
            {
                var close = new CloseConnectionOptions
                {
                    LocalUserId = IEosService.myPuid,
                    RemoteUserId = _remotePuid,
                    SocketId = _socketId
                };
                p2p.CloseConnection(ref close);
            }
        }

        _notifyPeerRequestId = 0;
        _notifyRegistered = false;
    }

    private void Abort(string reason)
    {
        CleanupP2P();
        _remotePuid = null;
        SetState(State.WaitingReady);
        OnAborted?.Invoke(reason);
    }

    private void SetState(State s)
    {
        if (_state == s) return;
        _state = s;
        OnStateChanged?.Invoke(_state);
    }


    // ====== �f�[�^���M�`�F�b�N ======
    int timeoutMs = 8;
    volatile bool _frame0Acked;

    async UniTask<bool> DataTransferCheck(ProductUserId remote, ushort inputBits,CancellationToken ct)
    {
        using var recvCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        var recvTask = ReceiveLoopAsync(recvCts.Token);

        try
        {
            Debug.Log("[�f�[�^���M�e�X�g] �J�n.");

            // 2) frame=0 input �𑗂�
            SendFrame0Input(remote, inputBits);
            Debug.Log($"[OneFrameNetTest] Sent frame=0 input={inputBits}");

            // 3) ACK�҂��itimeout�t���j
            bool ok = await WaitFrame0AckAsync(timeoutMs, ct);

            if (!ok)
            {
                Debug.LogWarning("[�f�[�^���M�e�X�g] �^�C���A�E�g: frame=0 ACK �͑���܂���ł���.");
                return false;
            }

            Debug.Log("[�f�[�^���M�e�X�g] ����: frame=0 ACK ���󂯎��܂���.");
            return true;
        }
        finally
        {
            // 4) ��M���[�v��~
            recvCts.Cancel();
            try { await recvTask; } catch { /* ignore */ }
        }

        async UniTask ReceiveLoopAsync(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested)
            {
                PumpReceiveOnce();
                await UniTask.Yield(PlayerLoopTiming.Update, ct);
            }
        }

        void PumpReceiveOnce()
        {
            var p2p = _getP2P?.Invoke();
            if (p2p == null) return;

            // ��M�𐔉�J���i��������Əd���̂�8�񂭂炢�j
            for (int i = 0; i < 8; i++)
            {
                byte[] buf = new byte[256];

                var receiveOptions = new ReceivePacketOptions
                {
                    LocalUserId = IEosService.myPuid,
                    MaxDataSizeBytes = (uint)buf.Length,
                    RequestedChannel = null,
                };

                var outPeerId = default(ProductUserId);
                var outSocketId = _socketId;
                var outChannel = default(byte);
                uint outBytes = 0;

                var r = p2p.ReceivePacket(ref receiveOptions, ref outPeerId, ref outSocketId, out outChannel, buf, out outBytes);
                if (r != Result.Success) break;
                if (outPeerId == null || outBytes == 0) continue;

                // 2�l�Œ�F����ȊO�͖���
                if (outPeerId != remote) continue;

                HandlePacket(outPeerId, buf, (int)outBytes);
            }
        }

        async UniTask<bool> WaitFrame0AckAsync(int timeoutMs, CancellationToken ct)
        {
            float start = Time.realtimeSinceStartup;

            while (!_frame0Acked)
            {
                float elapsedMs = (Time.realtimeSinceStartup - start) * 1000f;
                if (elapsedMs >= timeoutMs) return false;

                await UniTask.Yield(PlayerLoopTiming.Update, ct);
            }

            return true;
        }
    }

    void SendFrame0Input(ProductUserId remotePuid, ushort input)
    {
        var p2p = _getP2P?.Invoke(); // �����̎擾���@
        byte[] data = CreateInputPacket(0, input);

        var opt = new SendPacketOptions
        {
            LocalUserId = IEosService.myPuid,
            RemoteUserId = remotePuid,
            SocketId = _socketId,
            Channel = 0,
            Data = data,
            //DataLengthBytes = (uint)data.Length,
            //DeliveryReliability = PacketReliability.ReliableUnordered
        };

        p2p.SendPacket(ref opt);


        byte[] CreateInputPacket(int frame, ushort input)
        {
            byte[] buf = new byte[7];
            buf[0] = 0; // Input
            BitConverter.GetBytes(frame).CopyTo(buf, 1);
            BitConverter.GetBytes(input).CopyTo(buf, 5);
            return buf;
        }
    }

    void HandlePacket(ProductUserId from, byte[] data, int size)
    {
        byte type = data[0];
        int frame = BitConverter.ToInt32(data, 1);

        if (type == 0) // Input
        {
            ushort input = BitConverter.ToUInt16(data, 5);
            Debug.Log($"[NET] recv input frame={frame} input={input}");

            SendAck(from, frame);
        }

        void SendAck(ProductUserId remote, int frame)
        {
            byte[] buf = new byte[5];
            buf[0] = 1; // Ack
            BitConverter.GetBytes(frame).CopyTo(buf, 1);

            var opt = new SendPacketOptions
            {
                LocalUserId = IEosService.myPuid,
                RemoteUserId = remote,
                SocketId = _socketId,
                Channel = 0,
                Data = buf,
                //DataLengthBytes = (uint)buf.Length,
                //DeliveryReliability = PacketReliability.ReliableUnordered
            };

            _getP2P?.Invoke().SendPacket(ref opt);
        }
    }

}
