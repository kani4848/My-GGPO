using Cysharp.Threading.Tasks;
using System;
using System.Threading;
using UnityEngine;

public class MainSceneManager : MonoBehaviour, IMainSceneManager
{
    public MainGameState state { get; set; } = MainGameState.NONE;
    [SerializeField] UIManager_Main uiManager;

    MainGameSystem gameSystem;
    MainFlow_p2pTest p2p;
    CancellationTokenSource cts;

    int mainGameFrameCount = 0;

    System.Random rand;

    Action<int> fixedUpdateAction = null;

    private void OnDisable()
    {
        cts?.Cancel();
        cts?.Dispose();
        cts = null;
    }

    GameMode mode;

    IEosService eosService;

    private void Awake()
    {
        SoundManager.Instance.PlayBgm(BgmHandler.BgmType.Main);
        Application.targetFrameRate = 60;
        IGameManager.mainSceneManager = this;
        gameSystem = new();
    }

    public async UniTask StartFlow(IEosService _eosService, GameMode gameMode)
    {
        state = MainGameState.INITIALIZE;

        mode = gameMode;
        
        eosService = _eosService;

        if (mode == GameMode.Online)
        {
            rand = await GetRandWithSeed();
        }
        else
        {
            rand = new System.Random();
        }

        InitWithRand();

        switch (mode)
        {
            case GameMode.Online:
                break;
            case GameMode.Solo:
                //await StartSoloMode();
                break;
            case GameMode.Local:
                await GameLoop_Local();
                break;
            default:
                //await UniTask.Delay(10);
                break;
        }
    }

    public async UniTask<System.Random> GetRandWithSeed()
    {
        uint seed;
        
        p2p = new MainFlow_p2pTest();
        p2p.Init();
        if (p2p.isOwner)
        {
            seed = p2p.CreateAndSendSeed();
            await p2p.WaitForSeedReply();
        }
        else
        {
            seed = await p2p.WaitForRecievingSeed();
        }

        return new System.Random((int)seed);
    }

    void InitWithRand()
    {
        int chara_p1 = rand.Next(0, 13);
        int chara_p2 = rand.Next(0, 13);
        if (chara_p1 == chara_p2)
        {
            chara_p2 = chara_p1 + 1 > 12 ? 0 : chara_p1 + 1;
        }

        //uiManager.Init(p2p.isOwner, chara_p1, chara_p2);
        uiManager.Init(true, chara_p1, chara_p2);
    }

    async UniTask GameLoop_Online()
    {
        while (true)
        {
            RoundSetUp();

            await WaitRoundReady();

            await RoundStart();

            await MainLoop_Online(cts.Token);

            //����уX�e�[�g
            if (state == MainGameState.SHOT_WHITE_OUT)
            {
                await WhiteOut();
            }

            var result = await Result_Online();

            if (gameSystem.CheckRestart(result.gameResult)) break;

            await RoundReset();
        }

        //�������
        //���r�[�A�^�C�g���A�N�C�b�N�}�b�`���邩�I��
        //�N�C�b�N�}�b�`�Ȃ�}�b�`���O����
    }

    async UniTask GameLoop_Solo()
    {
        while (true)
        {
            RoundSetUp();

            await RoundStart();

            await MainLoop_Solo(cts.Token);

            //����уX�e�[�g
            if (state == MainGameState.SHOT_WHITE_OUT)
            {
                await WhiteOut();
            }

            var result = await Result_Online();

            if (gameSystem.CheckRestart(result.gameResult)) break;

            await RoundReset();

            //�X�e�[�W�A�b�v�f�[�g
        }

        //�v���C���[�s�k�Ȃ烊�g���C���
        //�Q�[���N���A�Ȃ珟�����
    }



    void RoundSetUp()
    {
        cts = new CancellationTokenSource();

        //���E���h�Z�b�g�A�b�v�B����ƒʐM�ł���܂őҋ@
        state = MainGameState.ROUND_SETUP;

        int nextSignal = rand.Next(0, 180);
        gameSystem.SetUpRound(nextSignal);
    }

    async UniTask WaitRoundReady()
    {

        p2p.SendRoundReadyMsg();//�؂�ւ�����
        await p2p.WaitAndRecieveReady();//�؂�ւ�����4
    }

    async UniTask RoundStart()
    {
        //�Q�[���J�n���o
        state = MainGameState.ROUND_START;
        await uiManager.RoundStart(gameSystem.roundCount == 0);
    }

    async UniTask MainLoop_Online(CancellationToken token)
    {
        state = MainGameState.MAIN_GAME;
        Peer_Online peer = new Peer_Online(PeerType.Local, eosService);
        fixedUpdateAction = peer.MainLoop;

        await UniTask.WaitUntil(() => peer.shot, cancellationToken: token);
    }


    async UniTask GameLoop_Local()
    {
        while (true)
        {
            while (true)
            {
                RoundSetUp();

                await RoundStart();

                await MainLoop_Local(cts.Token);

                //����уX�e�[�g
                if (state == MainGameState.SHOT_WHITE_OUT)
                {
                    await WhiteOut();
                }

                var result = await Result_Local();

                await RoundReset();

                if (gameSystem.CheckRestart(result.gameResult)) break;

            }

            state = MainGameState.END_MENU;
            SoundManager.Instance.PlayBgm(BgmHandler.BgmType.Title);
            uiManager.OnGameEnd(UIManager_Main.PlayerSide.P1);

            await UniTask.WaitUntil(() => state != MainGameState.END_MENU, cancellationToken: cts.Token);

            if (state == MainGameState.GO_TITLE) break;
        }
    }


    int shotFrame_p1 = -1;
    int shotFrame_p2 = -1;

    async UniTask MainLoop_Local(CancellationToken token)
    {
        state = MainGameState.MAIN_GAME;

        bool timeUp = false;

        fixedUpdateAction = (frame) =>
        {
            if (shotFrame_p1 == -1&& UnityEngine.Input.GetKeyDown(KeyCode.Space))
            {
                shotFrame_p1 = mainGameFrameCount;
            }

            if (shotFrame_p2 == -1 && UnityEngine.Input.GetKeyDown(KeyCode.Return))
            {
                shotFrame_p2 = mainGameFrameCount;
            }

            timeUp = gameSystem.MainLoop(mainGameFrameCount);

            mainGameFrameCount++;
        };

        await UniTask.WaitUntil(() => shotFrame_p1 != -1 || shotFrame_p2  != -1 || timeUp, cancellationToken: token);

        state = timeUp ? MainGameState.RESULT : MainGameState.SHOT_WHITE_OUT;
    }

    async UniTask<MainGameResultData> Result_Local()
    {
        //���U���g�X�e�[�g
        state = MainGameState.RESULT;
        fixedUpdateAction = null;
        MainGameResultData result = gameSystem.CheckResult(mainGameFrameCount, shotFrame_p1, shotFrame_p2);

        await uiManager.OnPreResult(result.gameResult);
        uiManager.OnResult(result);

        return result;
    }

    async UniTask MainLoop_Solo(CancellationToken token)
    {
        state = MainGameState.MAIN_GAME;
        int shotFrame = -1;

        fixedUpdateAction = (frame) =>
        {
            bool shot_player = UnityEngine.Input.GetKeyDown(KeyCode.Space);
            bool shot_cpu = false;
            shotFrame = frame;
        };

        await UniTask.WaitUntil(() => shotFrame != -1, cancellationToken: token);
    }

    async UniTask WhiteOut()
    {
        fixedUpdateAction = (frame) =>
        {
            if (shotFrame_p1 == -1 && UnityEngine.Input.GetKeyDown(KeyCode.Space))
            {
                shotFrame_p1 = mainGameFrameCount;
            }

            if (shotFrame_p2 == -1 && UnityEngine.Input.GetKeyDown(KeyCode.Return))
            {
                shotFrame_p2 = mainGameFrameCount;
            }

            mainGameFrameCount++;
        };

        await uiManager.OnWhiteOut();
    }

    async UniTask<MainGameResultData> Result_Online()
    {
        //���U���g�X�e�[�g
        state = MainGameState.RESULT;

        //���[�h���j�[�N��������������
        var pressedFrameData = p2p.GetBothInput();
        //���[�h���j�[�N��������������

        MainGameResultData result = gameSystem.CheckResult(mainGameFrameCount, pressedFrameData.local, pressedFrameData.remote);

        await uiManager.OnPreResult(result.gameResult);
        uiManager.OnResult(result);

        return result;
    }


    async UniTask RoundReset()
    {
        await UniTask.Delay(TimeSpan.FromSeconds(2));

        shotFrame_p1 = -1;
        shotFrame_p2 = -1;

        //���[�h���j�[�N��������������
        p2p?.OnRoundReset();
        //���[�h���j�[�N��������������

        cts?.Cancel();
        cts?.Dispose();
        cts = null;

        mainGameFrameCount = 0;
        await uiManager.OnRoundReset();
    }

    void FixedUpdate()
    {
        fixedUpdateAction?.Invoke(mainGameFrameCount);

        /*
        switch (state)
        {
            case MainGameState.MAIN_GAME:
                bool timeUp = gameSystem.MainLoop(mainGameFrameCount);

                if (timeUp)
                {
                    state = MainGameState.RESULT;
                    return;
                }

                //���j�[�N
                bool pressed_local = p2p.SendAndSaveLocalInput(mainGameFrameCount);
                bool pressed_remote = p2p.RecieveAndSaveRemoteInput();
                //���j�[�N

                if (pressed_local || pressed_remote)
                {
                    state = MainGameState.SHOT_WHITE_OUT;
                    return;
                }

                mainGameFrameCount++;
                break;

            //�V���b�g��̃z���C�g�A�E�g���ɂ����͂��L�^�A�덷�C��
            case MainGameState.SHOT_WHITE_OUT:

                //���j�[�N
                p2p.SendAndSaveLocalInput(mainGameFrameCount);
                p2p.RecieveAndSaveRemoteInput();
                //���j�[�N

                mainGameFrameCount++;
                break;
        }
         */
    }

    public void Rematch()
    {
        state = MainGameState.ROUND_SETUP;
    }

    public void GoLobby()
    {
        state = MainGameState.GO_LOBBY;
    }

    public void GoTitle()
    {
        state = MainGameState.GO_TITLE;
    }
}
