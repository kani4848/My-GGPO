using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Epic.OnlineServices;
using Epic.OnlineServices.Lobby;
using PlayEveryWare.EpicOnlineServices.Samples;
using PlayEveryWare.EpicOnlineServices;

using Cysharp.Threading;
using Cysharp.Threading.Tasks;
using System.Threading;
using System.Runtime.ConstrainedExecution;
using Unity.VisualScripting;

public class LobbyService_InLobby
{
    EOSLobbyManager _lobbyManager;

    private Dictionary<Lobby, LobbyDetails> _cachedResults = new();

    [SerializeField] private float memberPollIntervalSec = 2.0f;
    private CancellationTokenSource _memberPollCts;

    HashSet<LobbyMember> prevMembers = new();
    ProductUserId prevOwnerId;
    Dictionary<ProductUserId, long> lastBeatDic = new();
    Dictionary<ProductUserId, bool> deadMemberList = new();
    Dictionary<ProductUserId, string> memberNameList = new();

    UniTaskCompletionSource tcs_HB;

    private CancellationTokenSource _hbCts;
    private UniTask _hbTask;

    public LobbyService_InLobby(EOSLobbyManager lm)
    {
        _lobbyManager = lm;

        _memberPollCts?.Cancel();
        _memberPollCts?.Dispose();
        _memberPollCts = null;
    }

    //���r�[���C�x���g�J�n�E�I��===============================
    public void EnterLobbyAction()
    {
        _hbCts = new CancellationTokenSource();
        _hbTask = HeartbeatLoopAsync(_hbCts.Token);

        _lobbyManager.AddNotifyLobbyUpdate(OnLobbyUpdated);
        _lobbyManager.AddNotifyMemberUpdateReceived(OnMemberUpdated);

        _memberPollCts?.Cancel();
        _memberPollCts?.Dispose();
        _memberPollCts = new();

        CheckOtherMemberAlive(_memberPollCts.Token).Forget();

    }
    public void LeaveLobbyAction()
    {
        _hbCts?.Cancel();
        _hbCts?.Dispose();
        _hbCts = null;
        tcs_HB?.TrySetResult();

        _lobbyManager.RemoveNotifyLobbyUpdate(OnLobbyUpdated);
        _lobbyManager.RemoveNotifyMemberUpdate(OnMemberUpdated);

        _memberPollCts?.Cancel();
        _memberPollCts?.Dispose();
        _memberPollCts = null;

        memberNameList.Clear();
        prevMembers.Clear();
        prevOwnerId = null;

        lastBeatDic.Clear();
        deadMemberList.Clear();   
    }

    //�R�[���o�b�N�ƃ��[�v����===============================

    //���r�[���A�b�v�f�[�g���̃R�[���o�b�N����
    void OnLobbyUpdated()
    {
        Lobby currentLobby = _lobbyManager.GetCurrentLobby();
        if (currentLobby == null) return;
        if (LobbySceneManager.myPUID == null) return;

        var currentMembers = new HashSet<LobbyMember>(currentLobby.Members);
        if (currentMembers.Count <= 0) return;
        if (currentMembers == prevMembers) return;

        var currentPUIDs = new HashSet<ProductUserId>(currentMembers.Select(m => m.ProductId));
        var prevPUIDs = new HashSet<ProductUserId>(prevMembers.Select(m => m.ProductId));

        //�����C�x���g���s
        foreach (var joined in currentPUIDs.Except(prevPUIDs))
        {
            var joinedMember = currentMembers.FirstOrDefault(m => m.ProductId == joined);
            LobbyMemberEvent.RaiseJoined(joinedMember);
        }

        //�ގ��C�x���g���s
        foreach (var removed in prevPUIDs.Except(currentPUIDs))
        {
            var removedMember = prevMembers.FirstOrDefault(m => m.ProductId == removed);
            LobbyMemberEvent.RaiseLeft(removedMember);
        }

        prevMembers = currentMembers;
            
        //�I�[�i�[�ύX�C�x���g���s
        var newOwner = currentMembers.FirstOrDefault(m => currentLobby.IsOwner(m.ProductId));

        if (newOwner == null) return;

        if (newOwner.ProductId != prevOwnerId)
        {
            LobbyMemberEvent.RaiseOwnerChanged(newOwner);
            prevOwnerId = newOwner.ProductId;
        }
    }

    //�����o�[���A�b�v�f�[�g���̃R�[���o�b�N����
    private void OnMemberUpdated(string LobbyId, ProductUserId MemberId)
    {
        var currentLobby = _lobbyManager.GetCurrentLobby();
        if (currentLobby == null || !currentLobby.IsValid()) return;

        var members = currentLobby.Members;
        if (members.Count <= 0) return;
        var memberData = currentLobby.Members.First(m => m.ProductId == MemberId);

        //�������o�[�n�[�g�r�[�g�̍X�V
        LobbyAttribute lastBeatAtt;
        memberData.MemberAttributes.TryGetValue(LobbySceneManager.HB_KEY, out lastBeatAtt);

        if (lastBeatAtt != null)
        {
            var newLastBeat = long.Parse(memberData.MemberAttributes[LobbySceneManager.HB_KEY].AsString);

            if (lastBeatDic.ContainsKey(MemberId))
            {
                lastBeatDic[MemberId] = newLastBeat;
            }
            else
            {
                lastBeatDic.Add(MemberId, newLastBeat);
            }

            LobbyMemberEvent.RaiseHeartBeat(memberData);
        }

        UpdateMemberName();

        //���O�K�p�����C�x���g���s
        
        void UpdateMemberName()
        {
            string currentName = members.FirstOrDefault(m => m.ProductId == MemberId).DisplayName;
            string prevName;

            if (!memberNameList.TryGetValue(MemberId, out prevName))
            {
                LobbyMemberEvent.RaiseAppliedUserName(MemberId, currentName);
                memberNameList.Add(MemberId, currentName);
                return;
            }

            bool nameChanged = currentName != prevName;
            if (nameChanged) LobbyMemberEvent.RaiseAppliedUserName(MemberId, currentName);
            memberNameList[MemberId] = currentName;
        }
    }

    //�������o�[�n�[�g�r�[�g�̒�������`�F�b�N����
    async UniTask CheckOtherMemberAlive(CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            Lobby currentLobby = _lobbyManager.GetCurrentLobby();

            if (currentLobby == null)
            {
                await UniTask.Delay(TimeSpan.FromSeconds(1));
                continue;
            }

            var members = currentLobby.Members;
            if (members.Count <= 0)
            {
                await UniTask.Delay(TimeSpan.FromSeconds(1));
                continue;
            }

            Dictionary<ProductUserId, bool> newDeadList = new();

            foreach (LobbyMember member in members)
            {
                long lastBeat;
                if (!lastBeatDic.TryGetValue(member.ProductId, out lastBeat)) continue;

                var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

                bool newDead;
                bool wasDead;

                if (!deadMemberList.TryGetValue(member.ProductId, out wasDead))
                {
                    newDeadList.Add(member.ProductId, false);
                    continue;
                }
    
                newDead = now - lastBeat >= 5;

                if (newDead && wasDead != newDead)
                {
                    LobbyMemberEvent.RaiseDeath(member);
                }

                if (!newDead && wasDead != newDead)
                {
                    LobbyMemberEvent.RaiseRevive(member);
                }

                newDeadList.Add(member.ProductId, newDead);
            }

            deadMemberList = newDeadList;
            await UniTask.Delay(TimeSpan.FromSeconds(1));
        }
    }

    //�n�[�g�r�[�g��������===============================
    private async UniTask HeartbeatLoopAsync(CancellationToken ct)
    {
        // 1��ڂ𑦑���iUI�̔������ǂ��Ȃ�j
        while (!ct.IsCancellationRequested)
        {
            try
            {
                UpdateHBAttributeAsync();
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception e)
            {
                // �ꎞ���s���Ă����[�v�p���istale�����UI���ŋz���j
                Debug.LogWarning($"Heartbeat update failed: {e.Message}");
            }

            // interval
            await UniTask.Delay(TimeSpan.FromSeconds(1), cancellationToken: ct);
        }

        Debug.Log($"�ۓ��I��");

        void UpdateHBAttributeAsync()
        {
            tcs_HB = new UniTaskCompletionSource();

            var lobby = _lobbyManager.GetCurrentLobby();

            if (lobby == null || !lobby.IsValid())
            {
                tcs_HB.TrySetException(new Exception("Lobby is not valid"));
                return;
            }

            long nowUnix = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            string value = nowUnix.ToString();

            var attr = new LobbyAttribute
            {
                Key = LobbySceneManager.HB_KEY,
                ValueType = AttributeType.String,
                AsString = value,
                Visibility = LobbyAttributeVisibility.Public
            };

            _lobbyManager.SetMemberAttribute(attr);
        }
    }
}
