
public interface ITitleSceneManager
{
    public void ExitScene();
    public string GetPlayerName();
}
