using UnityEngine;

public class SingletonRoot : Singleton<SingletonRoot>
{

}
